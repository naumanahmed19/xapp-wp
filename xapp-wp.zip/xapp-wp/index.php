<?php
/**Silance is gold */