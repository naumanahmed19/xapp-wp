<?php

?>
<!-- wp:brand/bottom-tabs {"blockId":"55eef31d26754bc7907d87b925cd0107","settings":{"showSelectedLabels":false,"showUnselectedLabels":false,"tabs":[{"tabId":"home","index":0,"title":"Home Page","title_key":"","icon":{"uid":"505270887816b909af59d3d28b38f470","code":60122,"css":"home-solid"}},{"tabId":"search","index":1,"title":"Search","title_key":"","icon":{"uid":"62daeadcfbab1a93631405c16133d48d","code":60548,"css":"search-solid"}},{"tabId":"favourites","index":2,"title":"Favourites","title_key":"","icon":{"uid":"b964cb13964ea8fcef0754bcc1c6fbad","code":61220,"css":"allergies-solid"}},{"tabId":"account","index":3,"title":"Account","title_key":"","icon":{"uid":"366a9309c9230b659d515d920a673b31","code":60817,"css":"user"}}]}} -->
<div class="tab-wrap"><div><div class="mdc-tab-bar" role="tablist"><div class="mdc-tab-scroller"><div class="mdc-tab-scroller__scroll-area"><div class="mdc-tab-scroller__scroll-content"><div class="mdc-tab mdc-tab--active" role="tab" aria-selected="true" tabindex="0"><span class="mdc-tab__content"><span class="mdc-tab__text-label">Home Page</span></span><span class="mdc-tab-indicator mdc-tab-indicator--active"><span class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"></span></span><span class="mdc-tab__ripple"></span></div><div class="mdc-tab mdc-tab--active" role="tab" aria-selected="true" tabindex="1"><span class="mdc-tab__content"><span class="mdc-tab__text-label">Search</span></span><span class="mdc-tab-indicator"><span class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"></span></span><span class="mdc-tab__ripple"></span></div><div class="mdc-tab mdc-tab--active" role="tab" aria-selected="true" tabindex="2"><span class="mdc-tab__content"><span class="mdc-tab__text-label">Favourites</span></span><span class="mdc-tab-indicator"><span class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"></span></span><span class="mdc-tab__ripple"></span></div><div class="mdc-tab mdc-tab--active" role="tab" aria-selected="true" tabindex="3"><span class="mdc-tab__content"><span class="mdc-tab__text-label">Account</span></span><span class="mdc-tab-indicator"><span class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"></span></span><span class="mdc-tab__ripple"></span></div></div></div></div></div><!-- wp:brand/tab {"style":{"display":"block"},"tabId":"home","tabScreenIndex":0,"icon":{"uid":"505270887816b909af59d3d28b38f470","code":60122,"css":"home-solid"},"title":"Home Page","className":"brand-tab-screen"} -->
<div class="wp-block-brand-tab brand-tab-screen"></div>
<!-- /wp:brand/tab -->

<!-- wp:brand/tab {"style":{"display":"none"},"tabId":"search","tabScreenIndex":1,"icon":{"uid":"62daeadcfbab1a93631405c16133d48d","code":60548,"css":"search-solid"},"title":"Search","className":"brand-tab-screen"} -->
<div class="wp-block-brand-tab brand-tab-screen"></div>
<!-- /wp:brand/tab -->

<!-- wp:brand/tab {"style":{"display":"none"},"tabId":"favourites","tabScreenIndex":2,"icon":{"uid":"b964cb13964ea8fcef0754bcc1c6fbad","code":61220,"css":"allergies-solid"},"title":"Favourites","className":"brand-tab-screen"} -->
<div class="wp-block-brand-tab brand-tab-screen"></div>
<!-- /wp:brand/tab -->

<!-- wp:brand/tab {"style":{"display":"none"},"tabId":"account","tabScreenIndex":3,"icon":{"uid":"366a9309c9230b659d515d920a673b31","code":60817,"css":"user"},"title":"Account","className":"brand-tab-screen"} -->
<div class="wp-block-brand-tab brand-tab-screen"></div>
<!-- /wp:brand/tab --></div></div>
<!-- /wp:brand/bottom-tabs -->